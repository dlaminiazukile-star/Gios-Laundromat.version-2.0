import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

// Base path:
//  - Custom domain or normal web hosting (cPanel, Netlify, Vercel...): leave as '/'
//  - GitHub Pages WITHOUT a custom domain: build with VITE_BASE=/Gios-Laundromat/
const base = process.env.VITE_BASE || '/';

export default defineConfig({
  base,
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, '.'),
    },
  },
});
