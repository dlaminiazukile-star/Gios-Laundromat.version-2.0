import hero from './hero_laundry_shoes_1791137012366.jpg';
import van from './delivery_service_van_1791137038486.jpg';
import jordanLow from './jordan_low_restored_1791920472974.jpg';
import runnerMesh from './runner_mesh_clean_1791920473884.jpg';
import jordanTongue from './jordan_pair_tongue_1791920474499.jpg';
import hightopRed from './hightop_red_swoosh_1791920474885.jpg';
import hightopBefore from './hightop_before_clean_1791920474171.jpg';
import sneakerDirty from './sneaker_dirty_before_1791137049111.jpg';
import shoeSpaDetail from './shoe_spa_detail_1791137026726.jpg';

export const images = { hero, van, jordanLow, runnerMesh, jordanTongue, hightopRed, hightopBefore, sneakerDirty, shoeSpaDetail };
